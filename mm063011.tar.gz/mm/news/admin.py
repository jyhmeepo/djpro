from django.contrib import admin
from news.models import *
# Register your models here.

admin.site.register(Art)
admin.site.register(Mei)
admin.site.register(Mei2)
admin.site.register(Mei3)
admin.site.register(Mei4)
admin.site.register(Mei5)
admin.site.register(Mei7)
admin.site.register(Mei8)
admin.site.register(Mei9)
admin.site.register(Mei10)
admin.site.register(Mei11)
admin.site.register(Mei12)
admin.site.register(Mei13)
admin.site.register(Mei14)
admin.site.register(Mei15)
admin.site.register(Mei16)
