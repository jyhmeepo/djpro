from ku import *
import math
import random
import os
import time
from PIL import Image
import re
from django.core.urlresolvers import reverse

F('meinv','haokan')
op = open("../tmp/1.txt",'r')
# print(__file__)





# base = "/var/www/mm/ku"
# oldf = base+'nihao.txt'
# newf = base+'nihao.txt'
# try:
#     os.rename(
#         base+'nihao.txt',
#         base+'nihao2.txt'
#     )
# except:
#     pass
#
# print(os.path.abspath())












# for x in range(10):
#     # print(random.randint(1,10))
#     print(random.choice(
#         [
#             'nihao',
#             'nihao2',
#             'nihao3',
#             'nihao4',
#             'nihao5',
#             'nihao6',
#         ]
#     ))

