# create url in views
from django.core.urlresolvers import reverse
reverse('blogcontent',args=(14,))


#create url in templates
# {% url 'blogcontent' x.id %}


